// supabase functions deploy ai ; supabase secrets set ANTHROPIC_API_KEY=...
import { createClient } from "npm:@supabase/supabase-js@2";
const DAILY_LIMIT = 30;
Deno.serve(async (req) => {
  const sb = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
  const { data: { user } } = await sb.auth.getUser(req.headers.get("Authorization")!.replace("Bearer ", ""));
  if (!user) return new Response("unauthorized", { status: 401 });
  const day = new Date().toISOString().slice(0, 10);
  const { data: u } = await sb.from("ai_usage").select("calls").eq("owner", user.id).eq("day", day).maybeSingle();
  if ((u?.calls ?? 0) >= DAILY_LIMIT) return Response.json({ intent: "unknown", reply: "Daily assistant limit reached." });
  await sb.from("ai_usage").upsert({ owner: user.id, day, calls: (u?.calls ?? 0) + 1 });
  const { text, now, people } = await req.json();
  const r = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "x-api-key": Deno.env.get("ANTHROPIC_API_KEY")!, "anthropic-version": "2023-06-01", "content-type": "application/json" },
    body: JSON.stringify({ model: "claude-haiku-5-5", max_tokens: 200,
      system: `Now: ${now}. Known people: ${people}. Reply ONLY with JSON: {"intent":"add|plan|autoschedule|unknown","title":"","at":"ISO or null","remindBefore":10,"person":"name or null","reply":"short text if unknown"}`,
      messages: [{ role: "user", content: text }] }),
  });
  const j = await r.json();
  try { return Response.json(JSON.parse(j.content[0].text)); }
  catch { return Response.json({ intent: "unknown", reply: "I did not understand that." }); }
});
