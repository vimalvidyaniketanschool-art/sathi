create table people (id uuid primary key default gen_random_uuid(), owner uuid references auth.users not null,
  name text, relation text, phone text);
create table items (id uuid primary key default gen_random_uuid(), owner uuid references auth.users not null,
  title text, at timestamptz, remind_before int default 10, duration_min int default 30, priority int default 2,
  person_id uuid references people, kind text default 'task', done bool default false);
create table ai_usage (owner uuid, day date, calls int default 0, primary key (owner, day));
alter table people enable row level security; alter table items enable row level security;
create policy own_people on people for all using (owner = auth.uid());
create policy own_items on items for all using (owner = auth.uid());
-- Later, for memory search: create extension vector; alter table items add column embedding vector(768);

alter table items add column if not exists gcal_id text;

-- Step 1 additions: health preferences per user
create table prefs (owner uuid primary key references auth.users, data jsonb);
alter table prefs enable row level security;
create policy own_prefs on prefs for all using (owner = auth.uid());
