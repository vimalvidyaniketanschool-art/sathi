# Saathi Privacy Policy (template: edit, host publicly, and link it in Play Console and Google Cloud)
**What we access:** your Google account email, Google Calendar events (read today's events; create events for tasks you schedule), the microphone only while you tap the mic, and notifications permission for reminders.
**What we store:** tasks, people you add (name, relation, phone number), and health-reminder preferences, in a database hosted by Supabase, visible only to your account.
**AI processing:** when a voice command is complex, its text, the current time and the names of people you added are sent to an AI provider to understand the request. Audio is converted to text on your device and is not uploaded.
**Sharing:** we do not sell data or use it for ads. Data is shared only with the providers above to run the app.
**Deletion:** email <your address> to delete your account and all data.
**Google API disclosure:** use of information from Google APIs follows the Google API Services User Data Policy, including the Limited Use requirements.
