import 'package:extension_google_sign_in_as_googleapis_auth/extension_google_sign_in_as_googleapis_auth.dart';
import 'package:flutter/foundation.dart';
import 'package:googleapis/calendar/v3.dart' as cal;
import 'models.dart';
import 'repo.dart';

/// Google Calendar: read today's meetings, write tasks as events.
class CalendarSync {
  static Future<cal.CalendarApi?> _api() async {
    final c = await Auth.google.authenticatedClient();
    return c == null ? null : cal.CalendarApi(c);
  }

  /// Today's timed meetings. [ownIds] hides events this app created itself.
  static Future<List<Item>> todaysEvents(Set<String> ownIds) async {
    try {
      final api = await _api();
      if (api == null) return [];
      final n = DateTime.now(), s = DateTime(n.year, n.month, n.day);
      final r = await api.events.list('primary',
          timeMin: s.toUtc(), timeMax: s.add(const Duration(days: 1)).toUtc(),
          singleEvents: true, orderBy: 'startTime');
      return (r.items ?? [])
          .where((e) => e.start?.dateTime != null && !ownIds.contains(e.id))
          .map((e) {
        final st = e.start!.dateTime!.toLocal();
        final en = e.end?.dateTime?.toLocal() ?? st.add(const Duration(minutes: 30));
        return Item('g-${e.id}', e.summary ?? 'Event', at: st,
            durationMin: en.difference(st).inMinutes, kind: Kind.meeting, remindBefore: 0);
      }).toList();
    } catch (e) { debugPrint('Calendar read failed: $e'); return []; }
  }

  /// Creates a Calendar event for a scheduled task. The app's own notification
  /// handles the alert, so the event has no popup (avoids double reminders).
  static Future<String?> push(Item i) async {
    try {
      final api = await _api();
      if (api == null || i.at == null) return null;
      final ev = cal.Event(
          summary: i.title,
          start: cal.EventDateTime(dateTime: i.at!.toUtc()),
          end: cal.EventDateTime(dateTime: i.at!.add(Duration(minutes: i.durationMin)).toUtc()),
          reminders: cal.EventReminders(useDefault: false, overrides: []));
      return (await api.events.insert(ev, 'primary')).id;
    } catch (e) { debugPrint('Calendar write failed: $e'); return null; }
  }
}
