import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:speech_to_text/speech_to_text.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'models.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'calendar.dart';
import 'repo.dart';
import 'services.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // run with: --dart-define=SUPABASE_URL=... --dart-define=SUPABASE_ANON=...
  await Supabase.initialize(
      url: const String.fromEnvironment('SUPABASE_URL'),
      anonKey: const String.fromEnvironment('SUPABASE_ANON'));
  await Notifier.init(onTap: (p) {
    if (p == 'briefing') { onBriefing?.call(); return; }
    if (p != null && p.startsWith('wa:')) {
      launchUrl(Uri.parse('https://wa.me/${p.substring(3)}'), mode: LaunchMode.externalApplication);
    }
  });
  await Notifier.scheduleBriefing();
  runApp(const SaathiApp());
}

class Store extends ChangeNotifier {
  final items = <Item>[], people = <Person>[];
  final health = HealthPrefs();
  final calendarItems = <Item>[];
  Future<void> load() async {
    try { await Repo.load(items, people, health); } catch (e) { debugPrint('Load failed: $e'); }
    calendarItems..clear()..addAll(await CalendarSync.todaysEvents(items.map((i) => i.gcalId).whereType<String>().toSet()));
    for (final i in items) { Notifier.schedule(i, people); }
    notifyListeners();
  }
  void add(Item i) { items.add(i); Repo.saveItem(i); _push(i); Notifier.schedule(i, people); notifyListeners(); }
  void addPerson(Person p) { people.add(p); Repo.savePerson(p); notifyListeners(); }
  void done(Item i) { i.done = true; Repo.saveItem(i); notifyListeners(); }
  void _push(Item i) {
    if (i.at == null || i.gcalId != null) return;
    CalendarSync.push(i).then((id) { if (id != null) { i.gcalId = id; Repo.saveItem(i); } });
  }
  int autoSchedule() {
    final placed = scheduleDay(items.where((i) => i.at == null && !i.done).toList(),
        [...items.where((i) => i.at != null), ...calendarItems], DateTime.now());
    for (final i in placed) { Repo.saveItem(i); _push(i); Notifier.schedule(i, people); }
    notifyListeners();
    return placed.length;
  }
  void applyHealth() {
    Repo.savePrefs(health);
    for (final i in healthPlan(health)) { Notifier.schedule(i, people, daily: true); }
    notifyListeners();
  }
}

final store = Store();
void Function()? onBriefing;

class SaathiApp extends StatelessWidget {
  const SaathiApp({super.key});
  @override
  Widget build(BuildContext c) => MaterialApp(
      title: 'Saathi',
      theme: ThemeData(colorSchemeSeed: const Color(0xFF0F6B5C), useMaterial3: true),
      home: const AuthGate());
}

class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  int tab = 0;
  @override
  void initState() {
    super.initState();
    onBriefing = () => handle('schedule for today');
    store.load().then((_) async {
      final d = await FlutterLocalNotificationsPlugin().getNotificationAppLaunchDetails();
      if (d?.notificationResponse?.payload == 'briefing') handle('schedule for today');
    });
  }
  final _stt = SpeechToText(), _tts = FlutterTts();
  String reply = 'Tap the mic and say “schedule for today”.';

  Future<void> say(String t) async { setState(() => reply = t); await _tts.speak(t); }

  Future<void> listen() async {
    if (!await _stt.initialize()) return say('Speech recognition is not available.');
    _stt.listen(localeId: 'en_IN', onResult: (r) { if (r.finalResult) handle(r.recognizedWords); });
  }

  Future<void> handle(String text) async {
    final r = await Ai.understand(text, store.people);
    switch (r['intent']) {
      case 'plan':
        final now = DateTime.now();
        final today = [...store.items, ...store.calendarItems].where((i) => !i.done && i.at != null && i.at!.day == now.day).toList()
          ..sort((a, b) => a.at!.compareTo(b.at!));
        final open = store.items.where((i) => i.at == null && !i.done).length;
        await say(today.isEmpty && open == 0 ? 'You are free today.' :
            '${today.map((i) => '${i.title} at ${TimeOfDay.fromDateTime(i.at!).format(context)}').join('. ')}. $open tasks are unscheduled.');
      case 'autoschedule':
        await say('Placed ${store.autoSchedule()} tasks in your free time.');
      case 'add':
        final who = store.people.where((p) => p.name.toLowerCase() == '${r['person']}'.toLowerCase());
        store.add(Item(newId(), r['title'] ?? text,
            at: r['at'] == null ? null : DateTime.parse(r['at']),
            remindBefore: r['remindBefore'] ?? 10, personId: who.isEmpty ? null : who.first.id));
        await say('Added ${r['title']}.');
      default:
        await say(r['reply'] ?? 'Sorry, I did not catch that.');
    }
  }

  @override
  Widget build(BuildContext c) => ListenableBuilder(listenable: store, builder: (_, __) => Scaffold(
    appBar: AppBar(title: const Text('Saathi'), actions: [IconButton(icon: const Icon(Icons.logout), tooltip: 'Sign out', onPressed: Auth.signOut)]),
    body: Column(children: [
      Padding(padding: const EdgeInsets.all(12), child: Text(reply)),
      Expanded(child: [_today(), _groups(), _health()][tab]),
    ]),
    floatingActionButton: FloatingActionButton(onPressed: listen, child: const Icon(Icons.mic)),
    bottomNavigationBar: NavigationBar(selectedIndex: tab, onDestinationSelected: (i) => setState(() => tab = i),
      destinations: const [
        NavigationDestination(icon: Icon(Icons.today), label: 'Today'),
        NavigationDestination(icon: Icon(Icons.group), label: 'Groups'),
        NavigationDestination(icon: Icon(Icons.favorite), label: 'Health')]),
  ));

  Widget _today() => ListView(children: [
    Padding(padding: const EdgeInsets.symmetric(horizontal: 12), child: Wrap(spacing: 8, children: [
      FilledButton.icon(onPressed: () => handle('auto schedule'), icon: const Icon(Icons.auto_awesome), label: const Text('Auto-schedule')),
      OutlinedButton.icon(onPressed: () => _addTask(null), icon: const Icon(Icons.add), label: const Text('Task'))])),
    for (final i in store.items.where((i) => !i.done))
      ListTile(title: Text(i.title),
        subtitle: Text(i.at == null ? 'Unscheduled' : TimeOfDay.fromDateTime(i.at!).format(context)),
        trailing: IconButton(icon: const Icon(Icons.check), onPressed: () => store.done(i))),
  ]);

  Widget _groups() => ListView(children: [
    ListTile(title: const Text('Add family or friend'), leading: const Icon(Icons.person_add), onTap: _addPerson),
    for (final p in store.people)
      ListTile(title: Text(p.name), subtitle: Text(p.relation),
        trailing: IconButton(icon: const Icon(Icons.alarm_add), onPressed: () => _addTask(p))),
  ]);

  Widget _health() {
    final h = store.health;
    return ListView(children: [
      SwitchListTile(title: Text('Water every ${h.waterEveryMin} min'), value: h.water, onChanged: (v) { h.water = v; store.notifyListeners(); }),
      SwitchListTile(title: Text('Walk every ${h.walkEveryMin} min'), value: h.walk, onChanged: (v) { h.walk = v; store.notifyListeners(); }),
      SwitchListTile(title: const Text('Tea breaks (11:00, 16:30)'), value: h.tea, onChanged: (v) { h.tea = v; store.notifyListeners(); }),
      SwitchListTile(title: Text('Step check at 6 pm, goal ${h.stepGoal}'), value: h.steps, onChanged: (v) { h.steps = v; store.notifyListeners(); }),
      Padding(padding: const EdgeInsets.all(12), child: FilledButton(onPressed: () { store.applyHealth(); say('Health reminders are set.'); }, child: const Text('Apply daily reminders'))),
    ]);
  }

  Future<void> _addTask(Person? who) async {
    final t = TextEditingController();
    final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
      title: Text(who == null ? 'New task' : 'Reminder for ${who.name}'),
      content: TextField(controller: t, autofocus: true),
      actions: [TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Save'))]));
    if (ok != true || t.text.isEmpty) return;
    final time = await showTimePicker(context: context, initialTime: TimeOfDay.now());
    final n = DateTime.now();
    store.add(Item(newId(), t.text, personId: who?.id,
        at: time == null ? null : DateTime(n.year, n.month, n.day, time.hour, time.minute)));
  }

  Future<void> _addPerson() async {
    final n = TextEditingController(), r = TextEditingController(), p = TextEditingController();
    await showDialog(context: context, builder: (_) => AlertDialog(
      title: const Text('Add person'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: n, decoration: const InputDecoration(labelText: 'Name')),
        TextField(controller: r, decoration: const InputDecoration(labelText: 'Relation (Mom, friend)')),
        TextField(controller: p, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'WhatsApp number with country code'))]),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Save'))]));
    if (n.text.isNotEmpty) store.addPerson(Person(newId(), n.text, r.text, p.text));
  }
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});
  @override
  Widget build(BuildContext c) => StreamBuilder<AuthState>(
    stream: Supabase.instance.client.auth.onAuthStateChange,
    builder: (_, snap) => Supabase.instance.client.auth.currentSession == null
        ? const SignIn() : const Home());
}

class SignIn extends StatefulWidget {
  const SignIn({super.key});
  @override
  State<SignIn> createState() => _SignInState();
}

class _SignInState extends State<SignIn> {
  String? error;
  @override
  Widget build(BuildContext c) => Scaffold(body: Center(child: Padding(padding: const EdgeInsets.all(24),
    child: Column(mainAxisSize: MainAxisSize.min, children: [
      Text('Saathi', style: Theme.of(c).textTheme.headlineLarge),
      const SizedBox(height: 8),
      const Text('Your tasks, reminders and health nudges, by voice.', textAlign: TextAlign.center),
      const SizedBox(height: 24),
      FilledButton.icon(icon: const Icon(Icons.login), label: const Text('Continue with Google'),
        onPressed: () async {
          try { await Auth.signIn(); } catch (e) { setState(() => error = 'Sign-in failed: $e'); }
        }),
      if (error != null) Padding(padding: const EdgeInsets.only(top: 12), child: Text(error!)),
    ]))));
}
