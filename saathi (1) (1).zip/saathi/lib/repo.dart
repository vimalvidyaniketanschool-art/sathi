import 'package:flutter/foundation.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:uuid/uuid.dart';
import 'models.dart';

String newId() => const Uuid().v4();

/// Google sign-in on Android (native account picker), exchanged for a Supabase session.
/// Calendar scope is requested now so step 2 (Calendar sync) needs no second consent screen.
class Auth {
  static final google = GoogleSignIn(
    scopes: ['email', 'https://www.googleapis.com/auth/calendar.events'],
    serverClientId: const String.fromEnvironment('GOOGLE_WEB_CLIENT_ID'));

  static Future<void> signIn() async {
    final u = await google.signIn();
    if (u == null) return; // user cancelled
    final a = await u.authentication;
    if (a.idToken == null) throw Exception('No Google ID token. Check GOOGLE_WEB_CLIENT_ID.');
    await Supabase.instance.client.auth.signInWithIdToken(
        provider: OAuthProvider.google, idToken: a.idToken!, accessToken: a.accessToken);
  }

  static Future<void> signOut() async {
    await google.signOut();
    await Supabase.instance.client.auth.signOut();
  }
}

/// All database access. Writes never throw into the UI; failures are logged
/// (an offline queue is a later improvement).
class Repo {
  static SupabaseClient get _db => Supabase.instance.client;
  static String get _uid => _db.auth.currentUser!.id;

  static Future<void> load(List<Item> items, List<Person> people, HealthPrefs h) async {
    people..clear()..addAll((await _db.from('people').select()).map((r) =>
        Person(r['id'], r['name'] ?? '', r['relation'] ?? '', r['phone'] ?? '')));
    items..clear()..addAll((await _db.from('items').select().eq('done', false)).map((r) => Item(
        r['id'], r['title'] ?? '',
        at: r['at'] == null ? null : DateTime.parse(r['at']).toLocal(),
        remindBefore: r['remind_before'] ?? 10, durationMin: r['duration_min'] ?? 30,
        priority: r['priority'] ?? 2, personId: r['person_id'],
        kind: Kind.values.byName(r['kind'] ?? 'task'))..gcalId = r['gcal_id']));
    final p = await _db.from('prefs').select().maybeSingle();
    final d = p?['data'] as Map?;
    if (d != null) {
      h.water = d['water'] ?? true; h.walk = d['walk'] ?? true;
      h.tea = d['tea'] ?? true; h.steps = d['steps'] ?? true;
      h.waterEveryMin = d['waterEveryMin'] ?? 90; h.walkEveryMin = d['walkEveryMin'] ?? 120;
      h.stepGoal = d['stepGoal'] ?? 6000;
    }
  }

  static Future<void> _safe(Future<dynamic> f) async {
    try { await f; } catch (e) { debugPrint('Supabase write failed: $e'); }
  }

  static Future<void> savePerson(Person p) => _safe(_db.from('people').upsert(
      {'id': p.id, 'owner': _uid, 'name': p.name, 'relation': p.relation, 'phone': p.phone}));

  static Future<void> saveItem(Item i) async {
    if (i.kind == Kind.health) return; // regenerated from prefs, not stored
    await _safe(_db.from('items').upsert({
      'id': i.id, 'owner': _uid, 'title': i.title, 'at': i.at?.toUtc().toIso8601String(),
      'remind_before': i.remindBefore, 'duration_min': i.durationMin, 'priority': i.priority,
      'person_id': i.personId, 'kind': i.kind.name, 'done': i.done, 'gcal_id': i.gcalId}));
  }

  static Future<void> savePrefs(HealthPrefs h) => _safe(_db.from('prefs').upsert({
      'owner': _uid, 'data': {'water': h.water, 'walk': h.walk, 'tea': h.tea, 'steps': h.steps,
        'waterEveryMin': h.waterEveryMin, 'walkEveryMin': h.walkEveryMin, 'stepGoal': h.stepGoal}}));
}
