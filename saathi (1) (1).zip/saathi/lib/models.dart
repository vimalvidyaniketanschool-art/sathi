enum Kind { task, meeting, bill, birthday, health }

class Person {
  final String id, name, relation, phone; // phone with country code, e.g. 919812345678
  Person(this.id, this.name, this.relation, this.phone);
}

class Item {
  final String id;
  String title;
  DateTime? at; // null = unscheduled, auto-schedule can place it
  int remindBefore, durationMin, priority; // priority 1 (low) to 3 (high)
  String? personId; // reminder is about/for this family member or friend
  Kind kind;
  bool done;
  String? gcalId; // Google Calendar event id once pushed
  Item(this.id, this.title,
      {this.at, this.remindBefore = 10, this.durationMin = 30, this.priority = 2,
       this.personId, this.kind = Kind.task, this.done = false});
}

class HealthPrefs {
  int waterEveryMin = 90, walkEveryMin = 120, stepGoal = 6000;
  bool water = true, walk = true, tea = true, steps = true;
}
