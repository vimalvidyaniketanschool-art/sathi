import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:timezone/data/latest_all.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;
import 'models.dart';

/// ---------- Auto-schedule (pure Dart, free, no AI needed) ----------
/// Places unscheduled items into free gaps today, highest priority first.
List<Item> scheduleDay(List<Item> pending, List<Item> fixed, DateTime now,
    {int startH = 9, int endH = 20, int bufferMin = 10}) {
  final day = DateTime(now.year, now.month, now.day);
  final busy = fixed
      .where((f) => f.at != null && f.at!.isAfter(day) && f.at!.isBefore(day.add(const Duration(days: 1))))
      .map((f) => [f.at!, f.at!.add(Duration(minutes: f.durationMin))])
      .toList()
    ..sort((a, b) => a[0].compareTo(b[0]));
  var start = DateTime(day.year, day.month, day.day, startH);
  final nowRounded = now.add(Duration(minutes: 15 - now.minute % 15));
  if (nowRounded.isAfter(start)) start = nowRounded;
  final limit = DateTime(day.year, day.month, day.day, endH);
  final order = [...pending]..sort((a, b) => b.priority != a.priority
      ? b.priority.compareTo(a.priority) : a.durationMin.compareTo(b.durationMin));
  final placed = <Item>[];
  for (final t in order) {
    var s = start, moved = true;
    while (moved) {
      moved = false;
      final e = s.add(Duration(minutes: t.durationMin));
      for (final b in busy) {
        if (s.isBefore(b[1]) && e.isAfter(b[0])) { s = b[1].add(Duration(minutes: bufferMin)); moved = true; }
      }
    }
    final end = s.add(Duration(minutes: t.durationMin));
    if (end.isAfter(limit)) continue; // does not fit today
    t.at = s; placed.add(t);
    busy.add([s, end]);
    start = end.add(Duration(minutes: bufferMin));
  }
  return placed;
}

/// ---------- Health reminders: repeat daily ----------
List<Item> healthPlan(HealthPrefs p) {
  final d = DateTime.now();
  DateTime t(int h, [int m = 0]) => DateTime(d.year, d.month, d.day, h, m);
  final out = <Item>[];
  void every(String key, String title, int min, int fromH, int toH) {
    for (var x = t(fromH); x.hour < toH; x = x.add(Duration(minutes: min))) {
      out.add(Item('h-$key-${x.hour}${x.minute}', title, at: x, remindBefore: 0, kind: Kind.health));
    }
  }
  if (p.water) every('water', 'Time for a glass of water', p.waterEveryMin, 8, 21);
  if (p.walk) every('walk', 'Stand up and walk for 5 minutes', p.walkEveryMin, 10, 19);
  if (p.tea) {
    out.add(Item('h-tea-11', 'Tea break', at: t(11), remindBefore: 0, kind: Kind.health));
    out.add(Item('h-tea-16', 'Tea break', at: t(16, 30), remindBefore: 0, kind: Kind.health));
  }
  if (p.steps) out.add(Item('h-steps', 'Check your steps: goal ${p.stepGoal}', at: t(18), remindBefore: 0, kind: Kind.health));
  return out;
}

/// ---------- Local notifications (free, work offline) ----------
class Notifier {
  static final _n = FlutterLocalNotificationsPlugin();

  static Future<void> init({required void Function(String?) onTap}) async {
    tzdata.initializeTimeZones();
    tz.setLocalLocation(tz.getLocation((await FlutterTimezone.getLocalTimezone())));
    await _n.initialize(
      const InitializationSettings(android: AndroidInitializationSettings('@mipmap/ic_launcher')),
      onDidReceiveNotificationResponse: (r) => onTap(r.payload));
    final a = _n.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    await a?.requestNotificationsPermission();
    await a?.requestExactAlarmsPermission();
  }

  /// Daily 8 am notification; tapping it makes the app read out the day's plan.
  static Future<void> scheduleBriefing({int hour = 8}) async {
    final now = tz.TZDateTime.now(tz.local);
    var at = tz.TZDateTime(tz.local, now.year, now.month, now.day, hour);
    if (at.isBefore(now)) at = at.add(const Duration(days: 1));
    await _n.zonedSchedule(1, 'Good morning', 'Tap to hear your plan for today', at,
      const NotificationDetails(android: AndroidNotificationDetails('saathi', 'Reminders',
          importance: Importance.high, priority: Priority.high)),
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      matchDateTimeComponents: DateTimeComponents.time, payload: 'briefing');
  }

  /// Reminder for a family member/friend: the notification opens WhatsApp
  /// to that person (their phone gets no alert unless they also run the app).
  static Future<void> schedule(Item i, List<Person> people, {bool daily = false}) async {
    if (i.at == null || i.done) return;
    var when = tz.TZDateTime.from(i.at!.subtract(Duration(minutes: i.remindBefore)), tz.local);
    if (when.isBefore(tz.TZDateTime.now(tz.local))) {
      if (!daily) return;
      when = when.add(const Duration(days: 1));
    }
    final who = people.where((p) => p.id == i.personId);
    await _n.zonedSchedule(
      i.id.hashCode & 0x7fffffff,
      who.isEmpty ? 'Saathi' : 'For ${who.first.name}',
      i.title, when,
      const NotificationDetails(android: AndroidNotificationDetails('saathi', 'Reminders',
          importance: Importance.high, priority: Priority.high)),
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      matchDateTimeComponents: daily ? DateTimeComponents.time : null,
      payload: who.isEmpty ? null : 'wa:${who.first.phone}');
  }
}

/// ---------- AI: code first, LLM only when needed ----------
class Ai {
  static Future<Map<String, dynamic>> understand(String text, List<Person> people) async {
    final s = text.toLowerCase();
    if (RegExp(r'auto.?schedule|plan my (free )?time').hasMatch(s)) return {'intent': 'autoschedule'};
    if (RegExp(r"schedule for today|my day|today'?s plan|what.*today").hasMatch(s)) return {'intent': 'plan'};
    try { // Edge Function holds the Claude/Gemini key and enforces a per-user daily limit
      final r = await Supabase.instance.client.functions.invoke('ai', body: {
        'text': text, 'now': DateTime.now().toIso8601String(),
        'people': people.map((p) => p.name).toList()});
      return Map<String, dynamic>.from(r.data as Map);
    } catch (_) {
      return {'intent': 'unknown', 'reply': 'I could not reach the assistant. Try “schedule for today”.'};
    }
  }
}
