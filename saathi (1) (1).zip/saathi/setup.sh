#!/usr/bin/env bash
# Run from this folder with Flutter installed (CI does this automatically).
set -e
flutter create --org com.saathi --project-name saathi --platforms android app
rm -rf app/lib && cp -r lib app/lib && cp -r supabase app/supabase
cd app
flutter pub add flutter_local_notifications flutter_timezone timezone speech_to_text flutter_tts \
  supabase_flutter url_launcher uuid google_sign_in:^6.2.2 googleapis extension_google_sign_in_as_googleapis_auth
python3 ../patch_android.py
