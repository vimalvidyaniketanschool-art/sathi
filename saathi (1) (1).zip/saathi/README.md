# Saathi: build and release
## Get an APK with no local setup (GitHub Actions, free)
1. Create a private GitHub repo and upload everything in this folder (keep .github/).
2. One-time: make a stable signing key so Google sign-in keeps working:
   keytool -genkey -v -keystore debug.keystore -alias androiddebugkey -storepass android -keypass android -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=Android Debug,O=Android,C=US"
   keytool -list -v -keystore debug.keystore -storepass android | grep SHA1   (put this SHA-1 in your Google "Android" OAuth client)
   base64 -w0 debug.keystore   (save as secret DEBUG_KEYSTORE_BASE64)
3. Repo Settings, Secrets, Actions: SUPABASE_URL, SUPABASE_ANON, GOOGLE_WEB_CLIENT_ID, DEBUG_KEYSTORE_BASE64.
4. Actions tab, "Build Android", Run workflow. Download the saathi-android artifact: app-release.apk installs on any Android phone.
## Supabase and Google
Run supabase/schema.sql, deploy supabase/functions/ai (secret ANTHROPIC_API_KEY). Google Cloud: enable Calendar API, create Web + Android OAuth clients, add testers on the consent screen. Supabase: Auth, Providers, Google with the Web client ID/secret.
## Play Store (extra secrets)
Create an upload key (keytool -genkey -v -keystore upload.jks -alias upload -keyalg RSA -keysize 2048 -validity 10000), then add secrets UPLOAD_KEYSTORE_BASE64, UPLOAD_STORE_PASSWORD, UPLOAD_KEY_ALIAS, UPLOAD_KEY_PASSWORD. The workflow then also produces app-release.aab. Upload it in Play Console and add the SHA-1 shown under Play App Signing to your Android OAuth client.
Checklist: developer account (one-time fee), privacy policy URL (PRIVACY.md template), Data safety form, exact-alarm permission declaration, microphone justification, app icon and screenshots, content rating. New personal accounts may need a closed test before production; check current Play rules. Calendar scope needs Google OAuth verification before you exceed 100 test users.
Not compiled by me: expect version-related fixes on the first CI run.
