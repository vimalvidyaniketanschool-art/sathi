import glob, re
man_path = 'android/app/src/main/AndroidManifest.xml'
m = open(man_path).read()
perms = ''.join('<uses-permission android:name="android.permission.%s"/>\n' % p for p in
  ['INTERNET','RECORD_AUDIO','POST_NOTIFICATIONS','SCHEDULE_EXACT_ALARM','RECEIVE_BOOT_COMPLETED','VIBRATE'])
queries = '<queries><intent><action android:name="android.speech.RecognitionService"/></intent><intent><action android:name="android.intent.action.VIEW"/><data android:scheme="https"/></intent></queries>\n'
recv = '''<receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationReceiver"/>
<receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationBootReceiver"><intent-filter>
<action android:name="android.intent.action.BOOT_COMPLETED"/><action android:name="android.intent.action.MY_PACKAGE_REPLACED"/>
<action android:name="android.intent.action.QUICKBOOT_POWERON"/><action android:name="com.htc.intent.action.QUICKBOOT_POWERON"/></intent-filter></receiver>
'''
if 'RECORD_AUDIO' not in m:
    m = m.replace('<application', perms + queries + '<application', 1)
    m = m.replace('</application>', recv + '</application>', 1)
    m = re.sub(r'android:label="[^"]*"', 'android:label="Saathi"', m, count=1)
open(man_path, 'w').write(m)
for f in glob.glob('android/app/build.gradle*'):
    s = open(f).read()
    if f.endswith('.kts'):
        s = s.replace('compileOptions {', 'compileOptions {\n        isCoreLibraryDesugaringEnabled = true', 1)
        s = re.sub(r'minSdk\s*=\s*flutter\.minSdkVersion', 'minSdk = 23', s)
        s = s.replace('buildTypes {', '''signingConfigs {
        create("upload") {
            storeFile = file(System.getenv("UPLOAD_KEYSTORE") ?: "upload.jks")
            storePassword = System.getenv("UPLOAD_STORE_PASSWORD")
            keyAlias = System.getenv("UPLOAD_KEY_ALIAS")
            keyPassword = System.getenv("UPLOAD_KEY_PASSWORD")
        }
    }
    buildTypes {''', 1)
        s = s.replace('signingConfig = signingConfigs.getByName("debug")',
          'signingConfig = if (System.getenv("UPLOAD_KEYSTORE") != null) signingConfigs.getByName("upload") else signingConfigs.getByName("debug")')
        s += '\ndependencies {\n    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")\n}\n'
    else:
        print('WARNING: Groovy gradle file found; add desugaring, minSdk 23 and signing manually.')
    open(f, 'w').write(s)
print('Android patched')
